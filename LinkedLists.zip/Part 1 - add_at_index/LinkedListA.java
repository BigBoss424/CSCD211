   public class LinkedListA extends LinkedList
   {
      // Complete the 'add by index' method below.
		// The inherited class 'LinkedList' uses a dummy head node.
   	// Note if you use a 'find' method you must write it.
		// Be sure to test for an invalid index and throw an 
		// IndexOutOfBoundsException if found...
   	// Don't forget to update size!
   	
      public void add(int index, Comparable dataToAdd)
      {
      
 
 
 
 
 
       
      }// end add	
   

   }// end class
