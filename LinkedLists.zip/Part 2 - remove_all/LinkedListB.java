   public class LinkedListB extends LinkedList
   {
   	//  Complete the 'removeAll' method below such that
   	//  all occurances of a data value are removed from the list for
   	//  each element of the passed-in array.
   	//  For example, if the list contained values 3, 2, 2, 3, 4, 2, 5
   	//  and the passed-in collection of items to remove is 2, 4 the
   	//  resultant list would be reduced to 3, 3, 5.
   	//  Return 'true' if the list was altered - return 'false' if the list 
   	//  is unchanged.
		//  If the array is null, throw a NullPointerException.
		//  Note the inherited class 'LinkedList' uses a dummy head node.
      public boolean removeAll(Comparable [] array)
      {	
   	//  Your code goes here... 
 
 
 
 
 
 
 
 
      
      }// end removeAll
   
      	
   }// end class