public class ListTester 
{
	public static void main(String[] args) 
	{
		//  Create an ADT list for names...
		ListReferenceBased linkedList = new ListReferenceBased();
		
		//  Load up some nodes...
		linkedList.addNode(new FullName("Barack", "Obama"));
		linkedList.addNode(new FullName("Hillary", "Clinton"));
		linkedList.addNode(new FullName("Bill", "Clinton"));
		linkedList.addNode(new FullName("Tom", "Capaul"));
		linkedList.addNode(new FullName("John", "McCain"));
		
		//  Print the list...
		System.out.println(linkedList.toString());
	}
}
