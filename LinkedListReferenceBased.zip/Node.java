
public class Node 
{
    private Object item;
    private Node next;

//______________________________________________________________________________
  
    public Node(Object newItem)
    {
        item = newItem;
        next = null;
    } // end constructor

//______________________________________________________________________________
 
    public Node(Object newItem, Node nextNode)
    {
        item = newItem;
        next = nextNode;
    } // end constructor

//______________________________________________________________________________
 
    public void setItem(Object newItem)
    {
        item = newItem;
    } // end setItem

//______________________________________________________________________________
 
    public Object getItem()
    {
        return item;
    } // end getItem

//______________________________________________________________________________
 
    public void setNext(Node nextNode)
    {
        next = nextNode;
    }

//______________________________________________________________________________
 
    public Node getNext()
    {
        return next;
    }
//______________________________________________________________________________
    public String toString()
    {
    	return this.getItem().toString();
    }
//______________________________________________________________________________    
}