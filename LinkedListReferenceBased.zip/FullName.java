
public class FullName    // implements Comparable<FullName>
{
	private String fName;
	private String lName;
	
	public FullName(String f, String l)
	{
		this.fName = f;
		this.lName = l;
	}
	
	public int compareTo(Object rhs)
	{
		FullName that = (FullName)rhs;
		if (this.lName.compareToIgnoreCase(that.lName) == 0)
		{
			return this.fName.compareToIgnoreCase(that.fName);
		}
		else
		{
			return this.lName.compareToIgnoreCase(that.lName);
		}
	}
	
	@Override
	public String toString()
	{
		return this.lName + ", " + this.fName;
	}
}
