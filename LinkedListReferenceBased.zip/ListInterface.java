
public interface ListInterface
{
  // ****************************************************
  // Interface for the ADT list
  // ****************************************************
  // list operations:

  public boolean isEmpty();
  public int size();
  public void addNode(int item);
  public void deleteNode(int item) throws ListIndexOutOfBoundsException;
  public void deleteAll();
}
