import java.util.*;

public class SubStringGenerator
{
   private String string;
   
   public String substringParser(String src)
   {  this.string = src;
      String result = " ";
      int i = 0, 
          count = 0;
      if(i < count)
      { i++;
        result = result + src;
      }else
      return result;
      
   }//end substringParser

   public String toString()
   {
      return string;
   }
   
}//end SubStringGenerator