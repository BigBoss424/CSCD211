import java.util.Scanner;

public class SubStringTester
{
   public static void main(String [] args)
   {
      int choice;
      String string = " ";
      Scanner kb = new Scanner(System.in);
      
      System.out.println("Welcome to the SubString Parser");
       
      System.out.println("Please choose from the following options:");
      System.out.println("1) Enter a String");
      System.out.println("2) Generate the substrings ");
      System.out.println("3) Display the substrings");
      System.out.println("4) Quit ");
      System.out.print("Choice ------> ");
      choice = kb.nextInt();
      
         do
         {
         
            switch(choice)
            {
               case 1:
                      createString(string);
                      break;
                      
               case 2:
                      break;
                      
               case 3:
                      break;
                      
               case 4: System.out.println("Exitting Program");
                       System.exit(0);
                       break;
                      
               default:
                      break;
            
            
            }//end switch-case
      }while(choice != 4);
   }//end main
      
   public static String createString(String str)
   {
      Scanner kb = new Scanner(System.in);
      System.out.println("Please enter a String");
      str = kb.nextLine();
      return str;
   }//end createString
   

}//end SubStringTester

